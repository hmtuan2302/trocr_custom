import torch

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

num_workers = 16
should_log = True

batch_size = 4
train_epochs = 8
word_len_padding = 8  # will be overriden if the dataset contains labels longer than the constant
word_max_len = 128
learning_rate = 1e-6