from .main import TrocrPredictor

# expose the TrocrPredictor interface to other models
__all__ = ["TrocrPredictor"]
