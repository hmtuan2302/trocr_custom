from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from importlib.machinery import SourceFileLoader
from transformers import RobertaModel, AutoTokenizer, AutoModel
import os
from .configs import paths
from .configs import constants
import torch.nn as nn
import torch

def load_processor() -> TrOCRProcessor:
    processor = TrOCRProcessor.from_pretrained(paths.trocr_repo)
    cache_dir = '/content/drive/MyDrive/trocr/envibert'
    tokenizer = SourceFileLoader("envibert.tokenizer", os.path.join(cache_dir,'envibert_tokenizer.py')).load_module().RobertaTokenizer(cache_dir)
    processor.tokenizer = tokenizer
    return processor

def load_model(from_disk: bool, vocab_length) -> VisionEncoderDecoderModel:
    if from_disk:
        assert paths.model_path.exists(), f"No model existing at {paths.model_path}"
        model: VisionEncoderDecoderModel = VisionEncoderDecoderModel.from_pretrained(paths.model_path)
        debug_print(f"Loaded local model from {paths.model_path}")
    else:
        model: VisionEncoderDecoderModel = VisionEncoderDecoderModel.from_pretrained(paths.trocr_repo)
        # model: VisionEncoderDecoderModel = VisionEncoderDecoderModel.from_encoder_decoder_pretrained("google/vit-base-patch16-384", "nguyenvulebinh/envibert")
        # model.config.encoder = model_pretrained.config.encoder
        # model.encoder = model_pretrained.encoder

        model.decoder.output_projection = nn.Linear(1024, vocab_length, bias = False)
        model.decoder.config.vocab_size = vocab_length
        model.decoder.resize_token_embeddings(vocab_length)
        debug_print(f"Loaded pretrained model from huggingface ({paths.trocr_repo})")

    for param in model.parameters():
        param.requires_grad = False
    # for param in model.decoder.model.decoder.embed_tokens.parameters():
    #     param.requires_grad = True
    # for param in model.decoder.model.decoder.embed_positions.parameters():
    #     param.requires_grad = True
    # for param in model.decoder.output_projection.parameters():
    #     param.requires_grad = True 

    for param in model.decoder.parameters():
        param.requires_grad = True 
    total_params = sum(p.numel() for p in model.parameters())
    trainable_total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    debug_print(f"total params: {total_params}.")         
    debug_print(f"total params: {trainable_total_params}.")   
    debug_print(f"Using device {constants.device}.")

    model.to(constants.device)
    return model


def init_model_for_training(model: VisionEncoderDecoderModel, processor: TrOCRProcessor):
    model.config.decoder_start_token_id = processor.tokenizer.cls_token_id
    model.config.pad_token_id = processor.tokenizer.pad_token_id
    model.config.vocab_size = model.config.decoder.vocab_size


def debug_print(string: str):
    if constants.should_log:
        print(string)
