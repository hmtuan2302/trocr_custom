from .cli import cli

main = cli

if __name__ == "__main__":
    main()
